<?php
 $con = mysqli_connect("localhost", "farm", "farm-try", "farm", 3306);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>

<style>
    body{
    background-color: #f0f0f0;
}
header{
    display: flex;
    justify-content: space-between;
    align-items: center;
    padding: 20px;
    border: 2px solid black;
    background-color: teal;
    color: antiquewhite;
}

.nav{
    display: flex;
    justify-content: center;
    gap: 20px   ;
    
}
.nav li{
    list-style: none;
}

.nav li a{
    text-decoration: none;
    color: antiquewhite;
}

.open{
    display: flex;
    justify-content: center;
    align-items: center;
    margin-top: 400px;
}

.section{
    display: flex;
    justify-content: center;
    align-items: center;
    flex-wrap: wrap;
    margin-top: 100px;
}

.section2{
     display: flex;
    justify-content: center;
    align-items: center;
    flex-wrap: wrap;
    margin-top: 100px;
}

.card{
    width: 300px;
    background-color: white;
    border-radius: 8px;
    overflow: hidden; 
    margin: 20px;
    height: 450px;
}

.card img{
    width: 100%;
    height: auto;
    cursor: pointer;
    border-radius: 10px;
}

.card img:hover{
    transform: scale(0.9);
    transition: 0.3s;
}

.contents{
    display: flex;
    justify-content: center;
    align-items: center;
    flex-direction: column;
    padding: 10px;
}

.modal{
    display: none;
    justify-content: center;
    align-items: center;
    position: fixed;
    top: 0; left: 0;
    width: 100%;
    height: 100%;
    background-color: rgba(0, 0, 0, 0.8);
    z-index: 999;
    flex-direction: column;
}

.modal-content {
    width: 80vh;
    height: 80vh;
    object-fit:contain;
    border-radius: 50px;
    display: block;
    margin: auto;
}

.cartbox{
    background-color: white;
    width: 80%;
    height: 70%;
    border-radius: 10px;
    padding: 20px;
    text-align: center;
    color: black;
    overflow-y: auto;
}

.cartbox h2{
    margin-top: 0;
}

#cartItems{
    list-style: none;
    padding: 0;
    text-align: left;
}

#cartItems li{
    padding: 8px 0;
    border-bottom: 1px solid #ccc;
    margin-top: 20px;
    display: flex;
    justify-content: left;
    align-items: center;
    gap:100px
}
</style>
<body>
    <header>
        <div class="logo"><img src="" alt="Logo"></div>
        <div class="nav">
            <li><a href="">Home</a></li>
             <li><a href="" id="cartLink">Cart</a></li>
              
        </div>
    </header>

    
    <div class="section">
        <?php
        $query1 = "SELECT * FROM `tbl_products` LIMIT 3";
        $result1 = mysqli_query($con, $query1);
        while ($row = mysqli_fetch_assoc($result1)) {
            echo '
             <div class="card">
        <div><img src="' . $row['image'] . '"></div>
        <div class="contents"><h2>' . $row["product_name"] . '</h2>
        <h4>₱' .$row["price"] . '</h4>
        <p>Fresh Veggies at their BEST!</p>
        <button onClick="addToCart(\'' .$row["product_name"] . '\', ' .$row["price"] . ', \'' . $row["image"] . '\')">Add to Cart</button>
        </div>
        </div>';
        }
        ?>
    </div>

    <div class="section2">
        <?php
        $query1 = "SELECT * FROM `tbl_products` LIMIT 3 OFFSET 3";
        $result1 = mysqli_query($con, $query1);
        while ($row = mysqli_fetch_assoc($result1)) {
            echo '
            <div class="card">
        <div><img src="' . $row['image'] . '"></div>
        <div class="contents"><h2>' . $row["product_name"] . '</h2>
        <h4>₱' .$row["price"] . '</h4>
        <p>Fresh Veggies at their BEST!</p>
        <button onClick="addToCart(\'' .$row["product_name"] . '\', ' .$row["price"] . ', \'' . $row["image"] . '\')">Add to Cart</button>
        </div>
        </div>';
        }
        ?>
    </div>

     <div id="imgModal" class="modal">
        <span class="close">&times;</span>
        <img class="modal-content" id="modalImage">
    </div>

    <div id = "cartModal" class = "modal">
    <div class="cartbox">
    <span class = "close-cart">&times;</span>
    <h2>Your Cart</h2>
    <ul id="cartItems"></ul>
    </div>
    </div>

    </body>
    <script>
        const modal = document.getElementById('imgModal');
        const modalImg = document.getElementById('modalImage');
        const images = document.querySelectorAll('.card img');
        const closeBtn = document.querySelector('.close');

        const cartModal = document.getElementById('cartModal');
        const closeCart = document.querySelector('.close-cart');
        const cartItemsList = document.getElementById('cartItems');
    
    images.forEach((img) => {
    img.addEventListener('click', () => {
        modal.style.display = 'flex';
        modalImg.src = img.src;
        });
    });

    closeBtn.onclick = () => {
    modal.style.display = 'none';
  };

  window.onclick = (e) => {
    if (e.target === modal) {
        modal.style.display = 'none';
    }
    if (e.target === cartModal) {
        cartModal.style.display = 'none';
    }
};


  let cart = [];

  function addToCart(name, price, image){
    cart.push({name, price, image });
    updatecart();
    cartModal.style.display = 'flex';
  }

  function updatecart() {
    cartItemsList.innerHTML = '';
    cart.forEach(item => {
        const li = document.createElement('li');
        li.innerHTML = `
            <img src="${item.image}" style="width:100px; height:100px; object-fit:cover; margin-right:10px; vertical-align:middle; border-radius: 10px;">
            ${item.name} - ₱${item.price}
        `;
        cartItemsList.appendChild(li);
    });
}

  document.querySelector('#cartLink').addEventListener('click', function(e){
    e.preventDefault();
    cartModal.style.display = 'flex';
  });

  closeCart.onclick = () => {
    cartModal.style.display = 'none';
  };

  

    </script>
</html>