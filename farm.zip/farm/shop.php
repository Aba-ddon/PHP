<?php
$con = mysqli_connect("localhost", "practice", "prac-tice", "practice", 3307) 

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <style>
       
       header{
            display: flex;
            justify-content: space-between;
            align-items: center;
            flex-direction: row;
            height: 85px;
            background-color: teal;
            color: #FFE5B4;
            padding-left: 100px;
            padding-right: 100px;
            position: sticky;
            top: 0;
        }
        .navbar{
            display: flex;
            text-decoration: none;
            justify-content: space-between;
            padding-right: 20px;
            padding-left: 20px;
            list-style: none;
            gap: 50px;
            
        }

        .navbar li a{
            text-decoration: none;
            color: #FFE5B4;
        }

        .logo{
            align-items: center;
            
        }

        .section{
            margin-top: 5rem;
            display: flex;
            justify-content: center;
            height: 30rem;
            gap: 2rem;
            align-items: center;
        }

        .section2{
            margin-top: 5rem;
            display: flex;
            justify-content: center;
            height: 30rem;
            gap: 2rem;
            align-items: center;
        }

        .card{
            border: 2px solid black;
            height: 400px;
            width: 300px;
            justify-items: center;
        }

        

        .section .card img{
            
            height: 200px;
            justify-content: center;
            width: 280px;
            display: flex;
            padding: 5px;
            border: 1px solid black;
        }

        .section2 .card img{
            
            height: 200px;
            justify-content: center;
            width: 280px;
            display: flex;
            padding: 5px;
            border: 1px solid black;
        }

        .cardbody{
            justify-items: center;
        }

        button{
            background-color: teal;
            color: #FFE5B4;
            height: 40px;
            border-radius: 10px;
        }
        
       footer{
        background-color: teal;
        color: #FFE5B4;
        display: flex;
        justify-content: center;
        align-items: center;
        height: 70px;
       }

    </style>
</head>
<body>
    <header>
    <div class="logo"><img src="https://cdn.vectorstock.com/i/500p/77/87/vintage-farm-fresh-logo-vector-30227787.jpg" alt="Logo" width="70" height="60"></div>
    <div class="navbar">
        <li><a href="index.php">Home</a></li>
        <li><a href="">Cart</a></li>
    </div>
    </header>
    
    <div class="section">
<?php
$query1 = "SELECT * FROM tbl_products LIMIT 3";
$result1 = mysqli_query($con, $query1);
while ($row = mysqli_fetch_assoc($result1)) {
    echo '
    <div class="card">
        <div><img src="' . $row["Image"] . '" height="150px" width="250px"></div>
        <h2>' . $row["product_name"] . '</h2>
        <p>₱' . $row["Price"] . '</p>
        <p>Veggies at Their BEST!</p>
        <button>Add to Cart</button>
        <button onclick="openModal(\'' . $row["Image"] . '\')">View</button>
    </div>';
}
?>
</div>

<div class="section2">
<?php
$query2 = "SELECT * FROM tbl_products LIMIT 3 OFFSET 3";
$result2 = mysqli_query($con, $query2);
while ($row = mysqli_fetch_assoc($result2)) {
    echo '
    <div class="card">
        <div><img src="' . $row["Image"] . '" height="150px" width="250px"></div>
        <h2>' . $row["product_name"] . '</h2>
        <p>₱' . $row["Price"] . '</p>
        <p>Fresh and organic!</p>
        <button>Add to Cart</button>
        <button onclick="openModal(\'' . $row["Image"] . '\')">View</button>
    </div>';
}
?>
</div>

<footer>Copyright Caoili @2025</footer>


<div id="imageModal" 
style="display:none;
    position:fixed;
    top:0; left:0;
    width:100%;
    height:100%;
    background-color:rgba(0,0,0,0.8);
    justify-content:center;
    align-items:center;
    z-index:999;">
<span style="position:absolute;
    top:20px;
    right:40px;
    font-size:40px;
    color:white;
    cursor:pointer;"

      onclick="closeModal()">&times;</span>

    <img id="modalImage" src="" alt="Enlarged Image" style="max-width:90%; max-height:90%; box-shadow: 0 0 15px white;">
</div>

<script>
    function openModal(imageSrc) {
        document.getElementById("modalImage").src = imageSrc;
        document.getElementById("imageModal").style.display = "flex";
    }

    function closeModal() {
        document.getElementById("imageModal").style.display = "none";
    }

    
    window.onclick = function(event) {
        const modal = document.getElementById("imageModal");
        if (event.target === modal) {
            modal.style.display = "none";
        }
    };
</script>

</body>
</html>