<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <style>
        

        header{
            display: flex;
            justify-content: space-between;
            align-items: center;
            flex-direction: row;
            height: 85px;
            background-color: teal;
            color: #FFE5B4;
            padding-left: 100px;
            padding-right: 100px;
        }
        .navbar{
            display: flex;
            text-decoration: none;
            justify-content: space-between;
            padding-right: 20px;
            padding-left: 20px;
            list-style: none;
            gap: 50px;
            
        }

        .navbar li a{
            text-decoration: none;
            color: #FFE5B4;
        }

       

        .logo{
            align-items: center;
            
        }

        .banner{
            margin-top: 80px;
            display: flex;
            justify-content: center;
        }

        .shop{
            margin-top: 30px;
            display: flex;
            justify-content: center;
        }

        footer{
            background-color: teal;
            color: #FFE5B4;
        }

        .shop a{
            text-decoration: none;
            color: teal;
            font-size:30px;
        }

        .banimg{
            margin-top:20px;
            display:flex;
            justify-content: center;
            align-items: center;
        }
        .banimg img{
            height:500px;
            width: auto;
        }
    </style>
</head>
<body>
    <header>
    <div class="logo"><img src="https://cdn.vectorstock.com/i/500p/77/87/vintage-farm-fresh-logo-vector-30227787.jpg" alt="Logo" width="70" height="60"></div>
    <div class="navbar">
        <li><a href="index.php">Home</a></li>
        <li><a href="">Cart</a></li>
    </div>
    </header>
    <div class="banner">Welcome to Fresh Farm, bla bla bla</div>

    <div class = "banimg"><img src="Assets/freshfarm.jpg" alt=""></div>

    <div class="shop"> <a href="shop.php">Shop now</a></div>

    

</body>


</html>